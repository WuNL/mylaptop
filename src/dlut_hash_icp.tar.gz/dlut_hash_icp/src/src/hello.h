/*************************************************************************
	> File Name: hello.h
	> Author: 吴乃亮
	> Mail: wunailiang@gmail.com 
	> Created Time: Tue 20 May 2014 11:10:29 AM CST
 ************************************************************************/


#ifndef HELLO_H
#define HELLO_H 


#include<iostream>

using namespace std;
void hellofun();


#endif
