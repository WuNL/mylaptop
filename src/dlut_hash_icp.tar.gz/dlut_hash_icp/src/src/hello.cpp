/*************************************************************************
	> File Name: hello.cpp
	> Author: 吴乃亮
	> Mail: wunailiang@gmail.com 
	> Created Time: Tue 20 May 2014 11:09:03 AM CST
 ************************************************************************/

#include<iostream>
#include "hello.h"
using namespace std;

void hellofun()
{
    cout <<"hello" <<endl;
    return;
}
